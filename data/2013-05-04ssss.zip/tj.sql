#
# TABLE STRUCTURE FOR: tj_package
#

DROP TABLE IF EXISTS tj_package;

CREATE TABLE `tj_package` (
  `pack_id` int(11) NOT NULL AUTO_INCREMENT,
  `pack_name` varchar(30) DEFAULT NULL,
  `pack_database` varchar(30) DEFAULT NULL,
  `pack_create_time` int(11) DEFAULT NULL,
  `pack_create_uid` int(11) DEFAULT NULL,
  `pack_update_uid` int(11) DEFAULT NULL,
  `pack_update_time` int(11) DEFAULT NULL,
  `pack_comment` text,
  PRIMARY KEY (`pack_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='体检套餐：选择体验内容构成体检表即为体检套餐';

INSERT INTO tj_package (`pack_id`, `pack_name`, `pack_database`, `pack_create_time`, `pack_create_uid`, `pack_update_uid`, `pack_update_time`, `pack_comment`) VALUES (7, '2014', '2014tc', NULL, NULL, NULL, NULL, '2014套餐');
INSERT INTO tj_package (`pack_id`, `pack_name`, `pack_database`, `pack_create_time`, `pack_create_uid`, `pack_update_uid`, `pack_update_time`, `pack_comment`) VALUES (6, '2013', '2013tc', NULL, NULL, NULL, NULL, '2013套餐');


#
# TABLE STRUCTURE FOR: tj_result
#

DROP TABLE IF EXISTS tj_result;

CREATE TABLE `tj_result` (
  `res_id` int(11) NOT NULL AUTO_INCREMENT,
  `res_u_id` int(11) DEFAULT NULL COMMENT '体检结果用户id',
  `res_a_id` int(11) DEFAULT NULL COMMENT '体检医生id',
  `res_data` text COMMENT '体检结果',
  `res_comment` text COMMENT '体检结果注释',
  PRIMARY KEY (`res_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='体检结果';

