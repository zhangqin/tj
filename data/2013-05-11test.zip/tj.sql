#
# TABLE STRUCTURE FOR: tj_test
#

DROP TABLE IF EXISTS tj_test;

CREATE TABLE `tj_test` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `test` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO tj_test (`id`, `test`) VALUES (1, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (2, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (3, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (4, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (5, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (6, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (7, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (8, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (9, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (10, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (11, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (12, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (13, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (14, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (15, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (16, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (17, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (18, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (19, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (20, '2222');
INSERT INTO tj_test (`id`, `test`) VALUES (21, '2222');


