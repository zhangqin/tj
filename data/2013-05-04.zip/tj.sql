#
# TABLE STRUCTURE FOR: tj_backup
#

DROP TABLE IF EXISTS tj_backup;

CREATE TABLE `tj_backup` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(30) DEFAULT NULL,
  `b_path` varchar(30) DEFAULT NULL,
  `b_time` int(11) DEFAULT NULL,
  `b_comment` text,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='体检系统的备份';

#
# TABLE STRUCTURE FOR: tj_backup_category
#

DROP TABLE IF EXISTS tj_backup_category;

CREATE TABLE `tj_backup_category` (
  `b_c_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_c_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`b_c_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='体检系统的备份的分类';

