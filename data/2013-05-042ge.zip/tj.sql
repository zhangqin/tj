#
# TABLE STRUCTURE FOR: tj_menu
#

DROP TABLE IF EXISTS tj_menu;

CREATE TABLE `tj_menu` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '菜单id',
  `m_name` varchar(20) NOT NULL COMMENT '菜单名字',
  `m_href` varchar(50) NOT NULL COMMENT '菜单链接',
  `m_parent_id` int(11) DEFAULT NULL COMMENT '菜单父分类id',
  `m_weight` int(11) DEFAULT NULL COMMENT '菜单权限',
  `m_create_u_id` int(11) DEFAULT NULL,
  `m_create_time` int(11) DEFAULT NULL,
  `m_update_u_id` int(11) DEFAULT NULL,
  `m_update_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (1, '体检管理', '', 0, 333, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (2, '用户管理', '', 0, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (3, '系统管理', '', 0, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (4, '体检人', 'index.php/user/index', 2, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (5, '管理者', 'index.php/admin/index', 2, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (6, '数据库管理', 'index.php/data/index', 3, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (7, '菜单管理', 'index.php/cmenu/index', 3, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (8, '日志管理', 'index.php/log/log', 3, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (9, '权限管理', 'index.php/admin/role', 2, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (10, '模板管理', 'index.php', 3, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (11, '体检项目', 'index.php/ctj/project', 1, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (12, '体检分类', 'index.php/ctj/tsort', 1, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (13, '体检结果', 'index.php/ctj/tresult', 1, 2, NULL, NULL, NULL, NULL);
INSERT INTO tj_menu (`m_id`, `m_name`, `m_href`, `m_parent_id`, `m_weight`, `m_create_u_id`, `m_create_time`, `m_update_u_id`, `m_update_time`) VALUES (14, '体检套餐', 'index.php/ctj/package', 1, 2, NULL, NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: tj_log_category
#

DROP TABLE IF EXISTS tj_log_category;

CREATE TABLE `tj_log_category` (
  `log_c_id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`log_c_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='体检日志的分类';

