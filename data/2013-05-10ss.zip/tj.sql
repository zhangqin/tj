#
# TABLE STRUCTURE FOR: tj_admin
#

DROP TABLE IF EXISTS tj_admin;

CREATE TABLE `tj_admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(30) DEFAULT NULL,
  `admin_pwd` varchar(30) DEFAULT NULL,
  `admin_sex` int(1) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='体检管理者：1、老师  2、医生 3、管理者admin';

INSERT INTO tj_admin (`admin_id`, `admin_name`, `admin_pwd`, `admin_sex`) VALUES (1, '张勤', '123', 1);
INSERT INTO tj_admin (`admin_id`, `admin_name`, `admin_pwd`, `admin_sex`) VALUES (2, '张三', '123', 0);
INSERT INTO tj_admin (`admin_id`, `admin_name`, `admin_pwd`, `admin_sex`) VALUES (3, '李四', '123', 0);


#
# TABLE STRUCTURE FOR: tj_backup
#

DROP TABLE IF EXISTS tj_backup;

CREATE TABLE `tj_backup` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(30) DEFAULT NULL,
  `b_path` varchar(30) DEFAULT NULL,
  `b_time` int(11) DEFAULT NULL,
  `b_comment` text,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='体检系统的备份';

