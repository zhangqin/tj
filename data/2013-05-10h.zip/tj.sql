#
# TABLE STRUCTURE FOR: tj_2015tcc
#

DROP TABLE IF EXISTS tj_2015tcc;

CREATE TABLE `tj_2015tcc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ss` varchar(30) DEFAULT NULL,
  `fc` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tj_backup
#

DROP TABLE IF EXISTS tj_backup;

CREATE TABLE `tj_backup` (
  `b_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_name` varchar(30) DEFAULT NULL,
  `b_path` varchar(30) DEFAULT NULL,
  `b_time` int(11) DEFAULT NULL,
  `b_comment` text,
  PRIMARY KEY (`b_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='体检系统的备份';

